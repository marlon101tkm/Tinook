/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tb_gostei")
@XmlRootElement
@SequenceGenerator(name = "gostei_seq",initialValue = 0, allocationSize = 1)
public class gostei implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "gostei_seq")
    private Long id;
    
    @Column
    private Long livro_id;
    private Long usuario_id;
    private Date data_gostei;

    public Date getData_gostei() {
        return data_gostei;
    }

    public Long getId() {
        return id;
    }

    public Long getLivro_id() {
        return livro_id;
    }

    public Long getUsuario_id() {
        return usuario_id;
    }

    public void setData_gostei(Date data_gostei) {
        this.data_gostei = data_gostei;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setLivro_id(Long livro_id) {
        this.livro_id = livro_id;
    }

    public void setUsuario_id(Long usuario_id) {
        this.usuario_id = usuario_id;
    }
    
    
}
