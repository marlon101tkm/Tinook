/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tb_troca")
@XmlRootElement
@SequenceGenerator(name = "troca_seq",initialValue = 0, allocationSize = 1)
public class troca implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "troca_seq")
    private Long id;
    
    @Column
    private int livro_id;
    private Date data_troca;
    private int novo_dono_id;
    private int antigo_dono_id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getLivro_id() {
        return livro_id;
    }

    public void setLivro_id(int livro_id) {
        this.livro_id = livro_id;
    }

    public Date getData_troca() {
        return data_troca;
    }

    public void setData_troca(Date data_troca) {
        this.data_troca = data_troca;
    }

    public int getNovo_dono_id() {
        return novo_dono_id;
    }

    public void setNovo_dono_id(int novo_dono_id) {
        this.novo_dono_id = novo_dono_id;
    }

    public int getAntigo_dono_id() {
        return antigo_dono_id;
    }

    public void setAntigo_dono_id(int antigo_dono_id) {
        this.antigo_dono_id = antigo_dono_id;
    }
}
