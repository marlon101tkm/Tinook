/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tab_autor_livro")
@XmlRootElement
@SequenceGenerator(name = "autor_livro_seq",initialValue = 0, allocationSize = 1)
public class autor_livro implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "autor_livro_seq")
    private Long id;
    
    @Column
    private Long autor_id;
    private Long livro_id;

    public Long getID() {
        return id;
    }

    public void setID(Long ID) {
        this.id = ID;
    }

    public Long getAutor_id() {
        return autor_id;
    }

    public Long getLivro_id() {
        return livro_id;
    }

    public void setAutor_id(Long autor_id) {
        this.autor_id = autor_id;
    }

    public void setLivro_id(Long livro_id) {
        this.livro_id = livro_id;
    }
}
