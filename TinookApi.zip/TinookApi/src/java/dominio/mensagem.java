/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import java.sql.Time;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tb_mensagem")
@XmlRootElement
@SequenceGenerator(name = "mensagem_seq",initialValue = 0, allocationSize = 1)
public class mensagem implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mensagem_seq")
    private Long id;
    
    @Column(length = 255)
    private String mensagem;
    @Column
    private Time timestamp_enviado;
    private Long chat_id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public Time getTimestamp_enviado() {
        return timestamp_enviado;
    }

    public void setTimestamp_enviado(Time timestamp_enviado) {
        this.timestamp_enviado = timestamp_enviado;
    }

    public Long getChat_id() {
        return chat_id;
    }

    public void setChat_id(Long chat_id) {
        this.chat_id = chat_id;
    }
    
}
