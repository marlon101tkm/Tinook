/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tb_filtro")
@XmlRootElement
@SequenceGenerator(name = "filtro_seq",initialValue = 0, allocationSize = 1)
public class filtro implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "filtro_seq")
    private Long id;
    
    @Column
    private Long usuario_id;
    @Column(nullable = true)
    private Long autor_id;
    private float distancia;
    @Column(length = 100, nullable = true)
    private String genero;
    private String lingua;

    public Long getAutor_id() {
        return autor_id;
    }

    public float getDistancia() {
        return distancia;
    }

    public String getGenero() {
        return genero;
    }

    public Long getId() {
        return id;
    }

    public String getLingua() {
        return lingua;
    }

    public Long getUsuario_id() {
        return usuario_id;
    }

    public void setAutor_id(Long autor_id) {
        this.autor_id = autor_id;
    }

    public void setDistancia(float distancia) {
        this.distancia = distancia;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setLingua(String lingua) {
        this.lingua = lingua;
    }

    public void setUsuario_id(Long usuario_id) {
        this.usuario_id = usuario_id;
    }
    
}
