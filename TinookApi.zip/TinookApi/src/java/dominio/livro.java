/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominio;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "tb_livro")
@XmlRootElement
@SequenceGenerator(name = "livro_seq",initialValue = 0, allocationSize = 1)
public class livro implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "livro_seq")
    private Long id;
    
    @Column 
    private Long usuario_id;
    private Date lancamento;
    private int edicao;
    private int isbn;
    @Column(length = 255)
    private String titulo;
    @Column(length = 100)
    private String genero;
    private String lingua;
    @Column(length = 500)
    private String sinopse;

    public Long getId() {
        return id;
    }

    public Long getUsuario_id() {
        return usuario_id;
    }

    public Date getLancamento() {
        return lancamento;
    }

    public int getEdicao() {
        return edicao;
    }

    public int getIsbn() {
        return isbn;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getGenero() {
        return genero;
    }

    public String getLingua() {
        return lingua;
    }

    public String getSinopse() {
        return sinopse;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUsuario_id(Long usuario_id) {
        this.usuario_id = usuario_id;
    }

    public void setLancamento(Date lancamento) {
        this.lancamento = lancamento;
    }

    public void setEdicao(int edicao) {
        this.edicao = edicao;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setLingua(String lingua) {
        this.lingua = lingua;
    }

    public void setSinopse(String sinopse) {
        this.sinopse = sinopse;
    }
    
    
    
}
