/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author Carlos
 */
@javax.ws.rs.ApplicationPath("api")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(service.CORSFilter.class);
        resources.add(service.autorFacadeREST.class);
        resources.add(service.autor_livroFacadeREST.class);
        resources.add(service.chatFacadeREST.class);
        resources.add(service.filtroFacadeREST.class);
        resources.add(service.gosteiFacadeREST.class);
        resources.add(service.leuFacadeREST.class);
        resources.add(service.livroFacadeREST.class);
        resources.add(service.livro_fotoFacadeREST.class);
        resources.add(service.localizacaoFacadeREST.class);
        resources.add(service.matchFacadeREST.class);
        resources.add(service.mensagemFacadeREST.class);
        resources.add(service.trocaFacadeREST.class);
        resources.add(service.usuarioFacadeREST.class);
    }
    
}
